let countries = {
    "France": "Paris",
    "Germany": "Berlin",
    "Italy": "Rome",
    "Spain": "Madrid",
    "Portugal": "Lisbon",
    "Belgium": "Brussels",
    "Sweden": "Stockholm",
    "Norway": "Oslo",
    "Denmark": "Copenhagen",
    "Finland": "Helsinki",
    "Romania": "Bucharest",
    "Moldova": "Chișinău"
};

exports.handler = async (event) => {
    let param = event['country'];
    return {
        statusCode: 200,
        body: JSON.stringify({
            message: countries[param]
        }),
    };
};


